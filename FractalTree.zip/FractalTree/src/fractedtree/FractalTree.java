package fractedtree;
import java.applet.*;
import java.awt.*;
import java.lang.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FractalTree extends Applet {

	public void init(){

		setBackground(Color.CYAN);
		setSize(1200,600);

	}

	public void paint(Graphics g){
		try{
		makeTree(100,0,600,550,g);
		}
		catch(InterruptedException ex){
			System.out.print("invalid input");
		}
	}

	void makeTree(int length, int angle, int x, int y, Graphics g) throws InterruptedException {
		int xmove = (int)(Math.cos(Math.toRadians(angle+90))*length);
		int ymove = (int) (Math.sin(Math.toRadians(angle-90))*length);
		setForeground(Color.WHITE);
		g.drawLine(x,y,x+xmove,y+ymove);
		Thread.sleep(50);

		if(length >=1){
			makeTree(length-10, angle+30,x+xmove,y+ymove,g);
			makeTree(length-10, angle-30,x+xmove,y+ymove,g);


		}

	}// end of the make tree method
	

	}


